# BetCricket Site

Live Cricket Predictions UI built with React + Tailwind.

## Setup

1. Run `npm install`
2. Start with `npm start`

## API Key

Set `REACT_APP_CRICAPI_KEY` in your environment or in `.env` file
