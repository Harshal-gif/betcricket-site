import React, { useEffect, useState } from "react";
import axios from "axios";

const API_KEY = "09c8a9af-80cc-46d9-b5be-6aa4ed6c9943";
const API_URL = `https://cricapi.com/api/matches?apikey=${API_KEY}`;

export default function CricketTipsPage() {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchMatches() {
      try {
        const res = await axios.get(API_URL);

        // Check if response structure is valid
        if (res.data && Array.isArray(res.data.matches)) {
          const liveMatches = res.data.matches.filter((match) => match.matchStarted);
          setMatches(liveMatches);
        } else {
          throw new Error("Unexpected response format: 'matches' not found.");
        }
      } catch (err) {
        console.error("Failed to fetch matches", err);
        setError(err.message || "Unknown error occurred");
      } finally {
        setLoading(false);
      }
    }

    fetchMatches();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8 text-green-700">
          Live Cricket Matches & Predictions
        </h1>

        {loading && <p className="text-center text-gray-500">Loading...</p>}

        {error && (
          <p className="text-center text-red-500">
            Error loading matches: {error}
          </p>
        )}

        {!loading && !error && (
          <div className="grid gap-6">
            {matches.length === 0 ? (
              <p className="text-center text-gray-600">No live matches available.</p>
            ) : (
              matches.map((match, idx) => (
                <div
                  key={idx}
                  className="bg-white shadow-md rounded-2xl p-6 border-l-4 border-green-500"
                >
                  <div className="flex justify-between items-center mb-2">
                    <h2 className="text-xl font-semibold text-gray-800">
                      {match["team-1"]} vs {match["team-2"]}
                    </h2>
                    <span className="px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-700">
                      Live
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">Date: {match.date}</p>
                  <p className="text-green-700 font-medium">
                    Prediction: Coming Soon
                  </p>
                </div>
              ))
            )}
          </div>
        )}

        <footer className="text-center text-gray-500 text-sm mt-12">
          © 2025 BetCricketTips. All rights reserved.
        </footer>
      </div>
    </div>
  );
}
