import CricketTipsPage from './CricketTipsPage';
function App() {
  return <CricketTipsPage />;
}
export default App;
